package com.tool;

public class Calculation {
    public int add(int left, int right) {
        return left + right;
    }
}
